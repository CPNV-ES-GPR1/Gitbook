public interface IObserver {
    //Receive update from the observable
    void update(IObservable observable);
}
